document.getElementById("the-header").innerHTML = '<a class="header-link" href="index.html">Home</a> | <a class="header-link" href="games">Games</a>';
document.getElementById("games-header").innerHTML = '<a class="header-link">hi dude</a>';
